from __future__ import division
def lambda_handler(event, context):
   number1 = event['Number1']
   number2 = event['Number2']
   num1=int(number1)
   num2=int(number2)
   sum = num1 + num2
   product = num1 * num2
   difference = abs(num1 - num2)
   quotient = num1 / num2
   return {
       "Number1": num1,
       "Number2": num2,
       "Sum": sum,
       "Product": product,
       "Difference": difference,
       "Quotient": quotient
   }